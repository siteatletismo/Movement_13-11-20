<?php

$host = "localhost";
$db_name = "tcc_atletismo";
$username = "root";
$passworld = "";
//*$mysqli = mysqli_connect($host, $db_name, $username, $password);*//

try{
    $con = new PDO("mysql:host={$host};dbname={$db_name}", $username, $passworld);
}

//MOSTRA OS ERROS //

catch(PDOExpection $expection){
    echo "Connection error:" . $expection->getMessage();
}
?>

