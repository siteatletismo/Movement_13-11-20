  
<?php
if (! $_SESSION [ 'email' ]) {
	cabeçalho ( 'Localização: login_index.php' );
	sair ();
}