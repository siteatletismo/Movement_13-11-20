<?php
session_start ();
session_destroy ();
cabeçalho ( 'Localização: login_index.php' );
sair ();

?>