<?php
session_start();
?>

<html>
	<head>
		<title> Perfil </title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<link rel="stylesheet" href="assets/css/main.css"/>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" type="text/css" href="css/style.css">
		<link rel="stylesheet" type="text/css" href="css/grade.css">
		 
		<script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
		<script type="text/javascript" src="js/js.js"></script>
	</head>
	<body class="subpage">

		<!-- Header -->
			<header id="header">
				<div class="logo"><a href="index.html"> Movimente-se </a></div>
				<a href="#menu">Menu</a>
			</header>

		<!-- Nav -->
		<nav id="menu">
				<ul class="links">
					<li><a href="index.php">Home</a></li>
					<li><a href="generic.php"> Perfil </a></li>
                    <li><a href="elements.html">Elements</a></li>
                    <li><a href="cadastroUsuario.php"> Cadastro</a></li>
					<li><a href="login_index.php"> Login </a></li>
				</ul>
			</nav>
		<!-- One -->
			<section id="One" class="wrapper style3">
				<div class="inner">
					<header class="align-center">	
					</header>
				</div>
			</section>

		<!-- Two perfil -->
			<section id="two" class="wrapper style2">
				<div class="inner">
					<div class="box" style="background: #808080;">
						<div class="content">
		    
			<div class="base-home">
				<div class="rows base-perfil py-3">
				<div class="col-12">
				<div class="caixa">




					<form action="" method="post"> 
					<fieldset class="mt-1">
					<legend>Dados do cadastro</legend>
					<div class="rows">

						<div class="col-6">
							<label> </label>
							<div class="thumb" style=" width: 250px; height: 250px;">
							<img src="imagem/perfil.jpg">
							<input type="file" name="" value="">
							</div>
							<small class="text-center d-block"> </small>
						</div>
						
						<div class="col-6">
							<div class="py-1">
								<label> Nome </label>
								<input type="text" placeholder="Nome"> <?php print $_SESSION['nome_completo'] ?>
                               
						
							</div>
							<div class="py-1">
								<label> CPF </label>
								<input type="text" placeholder="CPF"> <?php print $_SESSION['cpf'] ?>
							</div>
							<div class="py-1">
								<label> Email </label>
								<input type="email" placeholder="Email"> <?php print $_SESSION['email'] ?>
								
		
							</div>
							<div class="py-1">
								<label> Senha </label>
								<input type="password" placeholder="Senha"> <?php print $_SESSION['senha'] ?>
							</div>
						</div>
					</div>
					</fieldset>
					
					
				
					
					<input type="submit" value="Atualizar perfil" class="btn d-table m-auto px-5 width-auto">
					</form>
				</div>
				</div>
				</div>
		
		
		
		</div> 
                         </div>
                            </div>
						</div>
					</div>
				</div>
			</section>

		<!-- Footer -->
			<footer id="footer">
				<div class="container">
					<ul class="icons">
						<li><a href="#" class="icon fa-twitter"><span class="label">Twitter</span></a></li>
						<li><a href="#" class="icon fa-facebook"><span class="label">Facebook</span></a></li>
						<li><a href="#" class="icon fa-instagram"><span class="label">Instagram</span></a></li>
						<li><a href="#" class="icon fa-envelope-o"><span class="label">Email</span></a></li>
					</ul>
				</div>
			
			</footer>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

		
	</body>
</html>

?>