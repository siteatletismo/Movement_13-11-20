<!DOCTYPE html>
<html lang="en">
<head>
	<title>Movement</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->
	<link rel="icon" type="" href="images/icons/favicon.svg"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
	<link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css"> 
<!--===============================================================================================-->
</head>
<body>

	<?php

if($_POST){
// include da conexao com o BD
include "config/conexao.php";
try{


// insert query
$query = "INSERT INTO cad_usuario SET nome_completo=:nome_completo, cpf=:cpf, email=:email, senha=:senha";

// prepare query for execution
$stmt = $con->prepare($query);

// posted values
$nome_completo 			= htmlspecialchars(strip_tags($_POST['nome_completo']));
$cpf					= htmlspecialchars(strip_tags($_POST['cpf']));
$email 					= htmlspecialchars(strip_tags($_POST['email']));
$senha					= htmlspecialchars(sha1($_POST['senha']));

//echo $nome_usuario;
//echo $nome_completo;
//echo $telefone;
//echo $email;
//echo $endereco;
//echo $senha;


// bind the parameters

$stmt->bindParam(':nome_completo', $nome_completo);
$stmt->bindParam(':cpf', $cpf);
$stmt->bindParam(':email', $email);
$stmt->bindParam(':senha', $senha);


// specify when this record was inserted to the database
//$data_criacao = date('Y-m-d H:i:s');
//$stmt->bindParam(':data_criacao', $data_criacao);


// Execute the query
if($stmt->execute()){
echo "<div class='alert alert-success'>Registro foi salvo.</div>";
}else{
echo "<div class='alert alert-danger'>Não foi possível salvar o
registro.</div>";
}
}


// show error
catch(PDOException $exception){
die('ERROR: ' . $exception->getMessage());
}
}

?>

	<div class="container-contact100" style="margin-top: -20px;">
		<div class="wrap-contact100">
			<form class="contact100-form validate-form" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post">
				<span class="contact100-form-title" style="font-family:  Montserrat; margin-top: -40px;" >
					Cadastro de Usuário
				</span>


				<div class="wrap-input100 validate-input" data-validate="Nome completo é obrigatório">
					<label class="label-input100" for="name"  style="font-family:  Montserrat;">Nome Completo</label>
					<input id="nome_completo" class="input100" type="text" name="nome_completo" placeholder="Digite seu nome completo...">
					<span class="focus-input100"></span>
				</div>

				<div class="wrap-input100 validate-input" data-validate="CPF é obrigatório">
					<label class="label-input100" for="name"  style="font-family:  Montserrat;">CPF</label>
					<input id="cpf" class="input100" type="text" name="cpf" placeholder="Digite seu CPF...">
					<span class="focus-input100"></span>
				</div>

				<div class="wrap-input100 validate-input" data-validate = "Email é obrigatório: ex@abc.xyz">
					<label class="label-input100" for="email"  style="font-family:  Montserrat;"> Endereço de Email </label>
					<input id="email" class="input100" type="text" name="email" placeholder="Digite seu email...">
					<span class="focus-input100"></span>
				</div>

				<div class="wrap-input100 validate-input" data-validate="Senha é obrigatório">
					<label class="label-input100" for="name"  style="font-family:  Montserrat;">Senha</label>
					<input id="senha" class="input100" type="password" name="senha" placeholder="Digite sua senha...">
					<span class="focus-input100"></span>
				</div>

				<a href="login_index.html" style="font-size: 20px;">Já possui uma conta?</a>
			</br>
			</br>
			

				<div class="container-contact100-form-btn">
					<button class="contact100-form-btn">
						Enviar
					</button>
				</div>

			</form>



			<div class="contact100-more flex-col-c-m" style="background-image: url('images/foto3.jpg'); height: 750px; ">
			</div>
		</div>
	</div>





<!--===============================================================================================-->
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/select2/select2.min.js"></script>
	<script>
		$(".js-select2").each(function(){
			$(this).select2({
				minimumResultsForSearch: 20,
				dropdownParent: $(this).next('.dropDownSelect2')
			});
		})
		$(".js-select2").each(function(){
			$(this).on('select2:open', function (e){
				$(this).parent().next().addClass('eff-focus-selection');
			});
		});
		$(".js-select2").each(function(){
			$(this).on('select2:close', function (e){
				$(this).parent().next().removeClass('eff-focus-selection');
			});
		});

	</script>
<!--===============================================================================================-->
	<script src="vendor/daterangepicker/moment.min.js"></script>
	<script src="vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
	<script src="vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
	<script src="js/main.js"></script>
	<!-- Global site tag (gtag.js) - Google Analytics -->
	<script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script>
	<script>
	  window.dataLayer = window.dataLayer || [];
	  function gtag(){dataLayer.push(arguments);}
	  gtag('js', new Date());

	  gtag('config', 'UA-23581568-13');
	</script>
</body>
</html>
