<?php
session_start();
include('conexao.php');

if(empty($_POST['email']) || empty($_POST['senha'])) {
	header('Location: login_index.php');
	exit();
}

$email = mysqli_real_escape_string($conexao, $_POST['email']);
$senha = mysqli_real_escape_string($conexao, $_POST['senha']);

$query = "SELECT * FROM `cad_usuario` WHERE email = '{$email}' and senha = '{$senha}'";
$result = mysqli_query($conexao, $query);

$row = mysqli_num_rows($result);

 if($row == 1) {
	$_SESSION['email'] = $email;
	$_SESSION['cpf'] = $cpf;
	$_SESSION['nome'] = $nome;
	$_SESSION['senha'] = $senha;
	header('Location: generic.php');
	exit();


		
		
} else {
	$_SESSION['nao_autenticado'] = true;
	header('Location: login_index.php');
	exit();
}
